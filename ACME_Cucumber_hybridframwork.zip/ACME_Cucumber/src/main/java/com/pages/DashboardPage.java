package com.pages;

import com.testng.api.base.ProjectSpecificMethod;

public class DashboardPage extends ProjectSpecificMethod {

}
